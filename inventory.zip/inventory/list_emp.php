
<?php

include "include/connection.php";



if(!empty($_POST['search'])){

  $search=$_POST['search'];
  $sql="SELECT * FROM employees ";
$sql="  where CONCAT(emp_name , emp_fname , emp_surname , emp_job) LIKE '%$search%'";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  


}else{

  $sql="SELECT * FROM employees";
  mysqli_set_charset($connection,"utf8");
  $result=mysqli_query($connection,$sql);

  
  
  
}




?>

<!doctype html>
<html lang="en">

<head>
  <meta charset="UTF-8"/>
     <title>Inventory</title>
   	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css" />
	<link rel="stylesheet" type="text/css" href="css/style.css">
	<link rel="stylesheet"  href="css/mycss.css">
</head>

<body>

  <div class="container-fluid">
    <div class="row"  id="top"> 
      <div class="col-md-3">
      <img class="img-responsive" src="img/images.jpg" alt="logo pic">
      </div>
      <div class="col-md-6">
        
      </div>
      <div class="col-md-3">
        <h2 id="debt_name">خدمات نرم افزاری</h2>
      </div>
    </div>
    <br>

    <div class="row">
        <div class="col-md-4" id="menu">
          <ul class="nav nav-pills">
            <li class="nav-item">
              <a class="nav-link active" href="add_item.php">جنس جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="add_emp.php">کارمند جدید</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="index.php">لیست اجناس</a>
            </li>
            
          </ul>
        </div>

        <div class="col-md-6" id="fsearch">
            <form class="form-inline" action="" method="post">
                <div class="form-group">
                  <input type="text" class="form-control" name="search" placeholder="جستجو">

                  <button type="submit" class="btn btn-success"> جستجو</button>
                </div>
                
                
              </form>
        </div>

        <div class="col-md-2">
          <h2 class="title">لیست کارمندان</h2>
        </div>

      </div>
      <br>

      <div class="row" id="content">
        <div class="col-md-12">
                  <table class="table table-striped" dir="rtl">
                    <thead>
                        <tr class="success">
                          <th>نام کارمند</th>
                          <th>نام پدر</th>
                          <th>تخلص</th>
                          <th>وظیفه</th>
                          <th>عملیات</th>

                        </tr>
                    </thead>
                    <TBODy>

                    <?php





                 $sql= "SELECT*FROM employees";
				 $result= mysqli_query($connection,$sql);
                   if(mysqli_num_rows($result)>0){
                      while($row=mysqli_fetch_row($result)){

                        echo "<tr>";
                            echo"<td>".$row[1]." </td>";
                            echo"<td>".$row[2]." </td>";
                            echo"<td>".$row[3]." </td>";
                            echo"<td>".$row[4]." </td>";
                            echo"<td><a href='edit_emp.php?id=".$row[1]."'>اصلاح</a> </td>";

                        echo "<tr>";

                      }

                   }
                    
                    ?>


                     

                      
                    </TBODy>


                  </table>
        </div>
      </div>

  </div>





  <script src="js/jquery.min.js"></script>
    <script src="js/parallax.min.js"></script>
    <script src="js/bootstrap.min.js"></script>


 
</body>

</html>