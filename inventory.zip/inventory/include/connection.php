<?php

$mysql_host='127.0.0.1';
$mysql_user='root';
$mysql_password='';
$database='inventory';

//@mysqli_connect($mysql_host,$mysql_user,$mysql_password) or die(" you can't connect to server"); // exit(" you can't connect to server");


$connection=mysqli_connect($mysql_host,$mysql_user,$mysql_password,$database);
if(!$connection){

    die(" you can't connect to server");


}

?>